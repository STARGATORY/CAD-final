pupil.addEventListener('click', function() {
    window.location.href = 'hidden_eye.html';
});