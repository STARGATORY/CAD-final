setTimeout(function() {
    window.location.href = "resistance_signIn.html";
}, 1000);